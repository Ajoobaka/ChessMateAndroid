# ChessMate Android

A native Android port of the uploaded Python/Tkinter chess app. The UI is built with Jetpack Compose and uses Chesslib for legal chess move generation and game-state rules.

## Features

- Player vs AI and local Player vs Player
- Easy / Medium / Hard AI settings
- 1, 3, 5, 10 and 30 minute clocks
- Legal moves, check detection, castling, en passant, and queen promotion
- Checkmate, stalemate, draw and timeout handling
- Last-move highlighting and legal-move markers
- Undo, restart and resign controls
- Offline gameplay after installation (the app requests no network permission)
- Mobile-first dark green UI with responsive board and player clocks

## Build an APK on Windows

1. Install **Android Studio** with Android SDK Platform 36 and Android SDK Build Tools.
2. Open the `ChessMateAndroid` folder in Android Studio.
3. Allow Gradle sync. The first build needs internet access to download Gradle and the Compose / Chesslib dependencies.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will create the debug APK at:

   `app/build/outputs/apk/debug/app-debug.apk`

Copy that APK to your Android phone and install it. Android may ask you to allow installation from that file manager/browser.

## Command-line build

The included `gradlew` / `gradlew.bat` scripts download Gradle 8.14.6 the first time they are run. You also need JDK 17+ and Android SDK Platform 36 installed.

Windows:

```bat
gradlew.bat :app:assembleDebug
```

macOS / Linux:

```bash
./gradlew :app:assembleDebug
```

The project uses Android Gradle Plugin 8.13.2, Kotlin 2.3.21, Compose BOM 2026.08.00 and Chesslib 1.3.7.

## Notes

- The original Tkinter interface and `winsound` calls are desktop-only, so the app was ported to Android rather than wrapped as-is.
- The AI uses material evaluation with alpha-beta minimax search: Easy selects a legal move randomly, Medium searches one ply, and Hard searches three plies. This is a lightweight teaching-game AI, not a tournament-strength chess engine or a certified ELO rating.
- Chesslib is distributed under the Apache License 2.0. Its dependency is resolved from JitPack during the first build.
