@echo off
setlocal
set VERSION=8.14.6
set APP_HOME=%~dp0
if defined GRADLE_USER_HOME (
  set GRADLE_HOME_DIR=%GRADLE_USER_HOME%\wrapper\dists\gradle-%VERSION%-bin\chessmate
) else (
  set GRADLE_HOME_DIR=%USERPROFILE%\.gradle\wrapper\dists\gradle-%VERSION%-bin\chessmate
)
set GRADLE_EXE=%GRADLE_HOME_DIR%\gradle-%VERSION%\bin\gradle.bat
if not exist "%GRADLE_EXE%" (
  echo Downloading Gradle %VERSION%...
  if not exist "%GRADLE_HOME_DIR%" mkdir "%GRADLE_HOME_DIR%"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ProgressPreference='SilentlyContinue'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%VERSION%-bin.zip' -OutFile '%GRADLE_HOME_DIR%\gradle.zip'; Expand-Archive -Path '%GRADLE_HOME_DIR%\gradle.zip' -DestinationPath '%GRADLE_HOME_DIR%' -Force; Remove-Item '%GRADLE_HOME_DIR%\gradle.zip'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_EXE%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
