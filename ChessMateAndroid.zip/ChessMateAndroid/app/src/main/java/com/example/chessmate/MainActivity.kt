package com.example.chessmate

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.key
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.github.bhlangonijr.chesslib.Board
import com.github.bhlangonijr.chesslib.Side
import com.github.bhlangonijr.chesslib.Square
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Background = Color(0xFF101713)
private val Panel = Color(0xFF1A241E)
private val PanelSoft = Color(0xFF202D25)
private val Accent = Color(0xFFC7F36B)
private val AccentDark = Color(0xFF94BD43)
private val Muted = Color(0xFF9BA89E)
private val LightSquare = Color(0xFFE7EBD9)
private val DarkSquare = Color(0xFF76966D)
private val SelectedSquare = Color(0xFFC6D86A)
private val WhiteText = Color(0xFFF4F6F0)
private val BlackText = Color(0xFF1A211C)

private const val START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(16, 23, 19)
        window.navigationBarColor = android.graphics.Color.rgb(16, 23, 19)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent,
                    onPrimary = Background,
                    background = Background,
                    surface = Panel,
                    onSurface = WhiteText
                )
            ) {
                ChessMateApp()
            }
        }
    }
}

@Composable
private fun ChessMateApp() {
    val board = remember { Board() }
    val moves = remember { mutableStateListOf<String>() }
    val scope = rememberCoroutineScope()

    var revision by remember { mutableIntStateOf(0) }
    var inGame by remember { mutableStateOf(false) }
    var gameRunning by remember { mutableStateOf(false) }
    var aiThinking by remember { mutableStateOf(false) }
    var selectedSquare by remember { mutableStateOf<String?>(null) }
    var finishMessage by remember { mutableStateOf<String?>(null) }
    var gameToken by remember { mutableIntStateOf(0) }

    var gameMode by remember { mutableStateOf("Player vs AI") }
    var difficulty by remember { mutableStateOf("Medium") }
    var timeControl by remember { mutableIntStateOf(10) }
    var whiteTime by remember { mutableIntStateOf(600) }
    var blackTime by remember { mutableIntStateOf(600) }

    val currentSide = remember(revision) { board.getSideToMove() }
    val legalMoves = remember(revision) { board.legalMoves().map { it.toString() } }
    val lastMove = moves.lastOrNull()
    val isCheck = remember(revision) { board.isKingAttacked() }

    fun updateTerminalState() {
        finishMessage = when {
            board.isMated() -> if (board.getSideToMove() == Side.WHITE) {
                "CHECKMATE · BLACK WINS"
            } else {
                "CHECKMATE · WHITE WINS"
            }
            board.isStaleMate() -> "STALEMATE · IT'S A DRAW"
            board.isDraw() -> "DRAW GAME"
            else -> null
        }
        if (finishMessage != null) gameRunning = false
    }

    fun resetGame() {
        gameToken += 1
        board.loadFromFen(START_FEN)
        moves.clear()
        selectedSquare = null
        finishMessage = null
        aiThinking = false
        whiteTime = timeControl * 60
        blackTime = timeControl * 60
        revision += 1
        inGame = true
        gameRunning = true
    }

    fun startAiTurn() {
        if (gameMode != "Player vs AI" || board.getSideToMove() != Side.BLACK || finishMessage != null) return
        val fen = board.getFen()
        val selectedDifficulty = difficulty
        val tokenAtStart = gameToken
        aiThinking = true
        scope.launch {
            val bestUci = withContext(Dispatchers.Default) {
                ChessAI.chooseMove(fen, selectedDifficulty)
            }
            if (tokenAtStart != gameToken || !inGame || !gameRunning) {
                aiThinking = false
                return@launch
            }
            val actualMove = board.legalMoves().firstOrNull { it.toString() == bestUci }
            if (actualMove != null) {
                board.doMove(actualMove)
                moves.add(actualMove.toString())
                revision += 1
                updateTerminalState()
            }
            aiThinking = false
        }
    }

    fun playMove(uci: String) {
        val move = board.legalMoves().firstOrNull { it.toString() == uci } ?: return
        board.doMove(move)
        moves.add(uci)
        selectedSquare = null
        revision += 1
        updateTerminalState()
        if (finishMessage == null) startAiTurn()
    }

    fun tapSquare(square: String) {
        if (!gameRunning || finishMessage != null || aiThinking) return
        if (gameMode == "Player vs AI" && board.getSideToMove() == Side.BLACK) return

        val pieceName = board.getPiece(Square.valueOf(square.uppercase())).name
        val ownPrefix = if (board.getSideToMove() == Side.WHITE) "WHITE_" else "BLACK_"

        if (selectedSquare == null) {
            if (pieceName.startsWith(ownPrefix)) selectedSquare = square
            return
        }

        val candidates = legalMoves.filter {
            it.length >= 4 && it.substring(0, 2) == selectedSquare && it.substring(2, 4) == square
        }
        if (candidates.isNotEmpty()) {
            // Promote to a queen by default, matching the desktop version.
            val chosen = candidates.firstOrNull { it.length == 4 || it.endsWith("q") } ?: candidates.first()
            playMove(chosen)
        } else if (pieceName.startsWith(ownPrefix)) {
            selectedSquare = square
        } else {
            selectedSquare = null
        }
    }

    fun undoMove() {
        if (aiThinking || moves.isEmpty()) return
        val undoCount = if (gameMode == "Player vs AI" && moves.size >= 2) 2 else 1
        repeat(undoCount) {
            if (moves.isNotEmpty()) {
                board.undoMove()
                moves.removeAt(moves.lastIndex)
            }
        }
        selectedSquare = null
        finishMessage = null
        gameRunning = true
        revision += 1
    }

    LaunchedEffect(gameRunning, revision) {
        if (gameRunning && finishMessage == null) {
            while (true) {
                delay(1000)
                if (board.getSideToMove() == Side.WHITE) {
                    whiteTime = (whiteTime - 1).coerceAtLeast(0)
                    if (whiteTime == 0) {
                        finishMessage = "TIME OUT · BLACK WINS"
                        gameRunning = false
                        break
                    }
                } else {
                    blackTime = (blackTime - 1).coerceAtLeast(0)
                    if (blackTime == 0) {
                        finishMessage = "TIME OUT · WHITE WINS"
                        gameRunning = false
                        break
                    }
                }
            }
        }
    }

    if (!inGame) {
        SetupScreen(
            gameMode = gameMode,
            onGameMode = { gameMode = it },
            difficulty = difficulty,
            onDifficulty = { difficulty = it },
            timeControl = timeControl,
            onTimeControl = { timeControl = it },
            onStart = { resetGame() }
        )
    } else {
        GameScreen(
            board = board,
            revision = revision,
            legalMoves = legalMoves,
            selectedSquare = selectedSquare,
            lastMove = lastMove,
            currentSide = currentSide,
            isCheck = isCheck,
            gameMode = gameMode,
            aiThinking = aiThinking,
            whiteTime = whiteTime,
            blackTime = blackTime,
            moveCount = moves.size,
            gameRunning = gameRunning,
            onSquareTap = { tapSquare(it) },
            onUndo = { undoMove() },
            onRestart = { resetGame() },
            onResign = {
                finishMessage = if (board.getSideToMove() == Side.WHITE) {
                    "WHITE RESIGNED · BLACK WINS"
                } else {
                    "BLACK RESIGNED · WHITE WINS"
                }
                gameRunning = false
            },
            onHome = {
                gameToken += 1
                gameRunning = false
                aiThinking = false
                inGame = false
                finishMessage = null
            }
        )
    }

    if (finishMessage != null) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = Panel,
            title = {
                Text("MATCH COMPLETE", color = Accent, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
            },
            text = {
                Text(finishMessage ?: "Game over", color = WhiteText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            },
            confirmButton = {
                TextButton(onClick = { resetGame() }) {
                    Text("PLAY AGAIN", color = Accent, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    gameToken += 1
                    gameRunning = false
                    inGame = false
                    finishMessage = null
                }) {
                    Text("HOME", color = Muted)
                }
            },
            properties = DialogProperties(usePlatformDefaultWidth = true)
        )
    }
}

@Composable
private fun SetupScreen(
    gameMode: String,
    onGameMode: (String) -> Unit,
    difficulty: String,
    onDifficulty: (String) -> Unit,
    timeControl: Int,
    onTimeControl: (Int) -> Unit,
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF17231B), Background, Background)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 22.dp, vertical = 24.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Accent),
                contentAlignment = Alignment.Center
            ) {
                Text("♞", color = Background, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("CHESSMATE", color = WhiteText, fontSize = 21.sp, fontWeight = FontWeight.Black, letterSpacing = 2.sp)
                Text("OFFLINE CHESS CLUB", color = Muted, fontSize = 10.sp, letterSpacing = 2.1.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(Panel)
                    .padding(horizontal = 11.dp, vertical = 7.dp)
            ) {
                Text("● OFFLINE", color = Accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
        }

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("MAKE YOUR", color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("NEXT MOVE.\nMAKE IT COUNT.", color = WhiteText, fontSize = 37.sp, lineHeight = 41.sp, fontWeight = FontWeight.Black, letterSpacing = (-1).sp)
            Text("A clean board. A sharp opponent. Your game, your pace.", color = Muted, fontSize = 14.sp, lineHeight = 21.sp)
        }

        SettingCard(title = "01  ·  GAME MODE", subtitle = "Choose how you want to play") {
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                ChoicePill("VS COMPUTER", gameMode == "Player vs AI", Modifier.weight(1f)) { onGameMode("Player vs AI") }
                ChoicePill("2 PLAYERS", gameMode == "Player vs Player", Modifier.weight(1f)) { onGameMode("Player vs Player") }
            }
        }

        if (gameMode == "Player vs AI") {
            SettingCard(title = "02  ·  AI LEVEL", subtitle = "Set the pressure") {
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    listOf("Easy", "Medium", "Hard").forEach { level ->
                        ChoicePill(level.uppercase(), difficulty == level, Modifier.weight(1f)) { onDifficulty(level) }
                    }
                }
                Text(
                    when (difficulty) {
                        "Easy" -> "A relaxed opponent for warm-up games."
                        "Hard" -> "Deeper look-ahead for a tougher match."
                        else -> "Balanced play with quick decisions."
                    },
                    color = Muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 9.dp)
                )
            }
        }

        SettingCard(title = if (gameMode == "Player vs AI") "03  ·  TIME CONTROL" else "02  ·  TIME CONTROL", subtitle = "Clock per player") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 3, 5, 10, 30).forEach { minutes ->
                    ChoicePill("${minutes}M", timeControl == minutes, Modifier.weight(1f)) { onTimeControl(minutes) }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(12.dp, RoundedCornerShape(20.dp))
                .clip(RoundedCornerShape(20.dp))
                .background(Accent)
                .clickable(onClick = onStart)
                .padding(vertical = 19.dp),
            contentAlignment = Alignment.Center
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text("START GAME", color = Background, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                Spacer(Modifier.width(12.dp))
                Text("→", color = Background, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            }
        }

        Text(
            "NO ACCOUNT  ·  NO INTERNET  ·  JUST CHESS",
            color = Color(0xFF748078),
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.4.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        )
    }
}

@Composable
private fun SettingCard(
    title: String,
    subtitle: String,
    content: @Composable () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Panel)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        Text(title, color = Accent, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
        Text(subtitle, color = Muted, fontSize = 12.sp)
        content()
    }
}

@Composable
private fun ChoicePill(
    label: String,
    selected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) Accent else PanelSoft)
            .border(1.dp, if (selected) Accent else Color(0xFF334238), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 5.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Background else WhiteText,
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = 0.7.sp,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
private fun GameScreen(
    board: Board,
    revision: Int,
    legalMoves: List<String>,
    selectedSquare: String?,
    lastMove: String?,
    currentSide: Side,
    isCheck: Boolean,
    gameMode: String,
    aiThinking: Boolean,
    whiteTime: Int,
    blackTime: Int,
    moveCount: Int,
    gameRunning: Boolean,
    onSquareTap: (String) -> Unit,
    onUndo: () -> Unit,
    onRestart: () -> Unit,
    onResign: () -> Unit,
    onHome: () -> Unit
) {
    val whiteTurn = currentSide == Side.WHITE
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF17231B), Background, Background)))
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(39.dp)
                    .clip(RoundedCornerShape(13.dp))
                    .background(PanelSoft)
                    .clickable(onClick = onHome),
                contentAlignment = Alignment.Center
            ) {
                Text("‹", color = WhiteText, fontSize = 29.sp, lineHeight = 30.sp)
            }
            Spacer(Modifier.width(11.dp))
            Column {
                Text("CHESSMATE", color = WhiteText, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 1.8.sp)
                Text("LIVE MATCH  ·  ${gameMode.uppercase()}", color = Muted, fontSize = 9.sp, letterSpacing = 1.3.sp)
            }
            Spacer(Modifier.weight(1f))
            Box(
                modifier = Modifier.clip(CircleShape).background(Panel).padding(horizontal = 10.dp, vertical = 7.dp)
            ) {
                Text(if (gameRunning) "● LIVE" else "○ PAUSED", color = if (gameRunning) Accent else Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        PlayerClockCard(
            name = if (gameMode == "Player vs AI") "AI OPPONENT" else "BLACK PLAYER",
            subtitle = if (gameMode == "Player vs AI") "BLACK  ·  ${if (aiThinking) "THINKING" else if (!whiteTurn) "TO MOVE" else "WAITING"}" else "BLACK PIECES",
            time = blackTime,
            active = !whiteTurn && gameRunning,
            black = true
        )

        ChessBoardView(
            board = board,
            revision = revision,
            legalMoves = legalMoves,
            selectedSquare = selectedSquare,
            lastMove = lastMove,
            enabled = gameRunning && !aiThinking,
            onSquareTap = onSquareTap
        )

        PlayerClockCard(
            name = if (gameMode == "Player vs AI") "YOU" else "WHITE PLAYER",
            subtitle = if (gameMode == "Player vs AI") "WHITE  ·  ${if (whiteTurn) "YOUR MOVE" else "WAITING"}" else "WHITE PIECES",
            time = whiteTime,
            active = whiteTurn && gameRunning,
            black = false
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Panel)
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(if (isCheck) Color(0xFFFF766B) else Accent))
            Spacer(Modifier.width(9.dp))
            Text(
                when {
                    aiThinking -> "AI IS THINKING…"
                    isCheck -> "CHECK · KING UNDER ATTACK"
                    whiteTurn -> "WHITE TO MOVE"
                    else -> "BLACK TO MOVE"
                },
                color = if (isCheck) Color(0xFFFF958A) else WhiteText,
                fontSize = 10.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.2.sp
            )
            Spacer(Modifier.weight(1f))
            Text("MOVE ${moveCount / 2 + 1}", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(9.dp), modifier = Modifier.fillMaxWidth()) {
            ActionButton("↶", "UNDO", Modifier.weight(1f), enabled = moveCount > 0 && !aiThinking, onClick = onUndo)
            ActionButton("⟳", "RESTART", Modifier.weight(1.15f), enabled = !aiThinking, onClick = onRestart)
            ActionButton("⚑", "RESIGN", Modifier.weight(1f), enabled = gameRunning && !aiThinking, danger = true, onClick = onResign)
        }
        Text(
            "${if (gameMode == "Player vs AI") "PLAYING OFFLINE" else "LOCAL TWO-PLAYER"}  ·  ${(revision / 2) + 1} POSITION",
            color = Color(0xFF748078),
            fontSize = 9.sp,
            letterSpacing = 1.3.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
        )
    }
}

@Composable
private fun PlayerClockCard(
    name: String,
    subtitle: String,
    time: Int,
    active: Boolean,
    black: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(17.dp))
            .background(if (active) Color(0xFF263829) else Panel)
            .border(1.dp, if (active) Accent.copy(alpha = 0.55f) else Color(0xFF2B3A30), RoundedCornerShape(17.dp))
            .padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(39.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(if (black) Color(0xFF090C0A) else Color(0xFFE5E9DD)),
            contentAlignment = Alignment.Center
        ) {
            Text(if (black) "♚" else "♔", color = if (black) Color(0xFFF0F1E9) else Color(0xFF20271F), fontSize = 28.sp)
        }
        Spacer(Modifier.width(11.dp))
        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(name, color = WhiteText, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 1.sp)
            Text(subtitle, color = Muted, fontSize = 9.sp, letterSpacing = 0.8.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text(formatTime(time), color = if (active) Accent else WhiteText, fontSize = 24.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
            Text(if (active) "YOUR CLOCK" else "TIME LEFT", color = Muted, fontSize = 8.sp, letterSpacing = 1.2.sp)
        }
    }
}

@Composable
private fun ChessBoardView(
    board: Board,
    revision: Int,
    legalMoves: List<String>,
    selectedSquare: String?,
    lastMove: String?,
    enabled: Boolean,
    onSquareTap: (String) -> Unit
) {
    key(revision) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .shadow(18.dp, RoundedCornerShape(9.dp))
                .clip(RoundedCornerShape(9.dp))
                .border(2.dp, Color(0xFF394B3C), RoundedCornerShape(9.dp))
        ) {
            val cellFont = (maxWidth.value / 8f * 0.68f).sp
            Column(Modifier.fillMaxSize()) {
                for (rank in 7 downTo 0) {
                    Row(Modifier.weight(1f)) {
                        for (file in 0..7) {
                            val square = "${('a'.code + file).toChar()}${rank + 1}"
                            val squareEnum = Square.valueOf(square.uppercase())
                            val pieceName = board.getPiece(squareEnum).name
                            val hasPiece = pieceGlyph(pieceName).isNotEmpty()
                            val isSelected = selectedSquare == square
                            val isLastMove = lastMove?.let {
                                it.length >= 4 && (it.substring(0, 2) == square || it.substring(2, 4) == square)
                            } ?: false
                            val isTarget = selectedSquare != null && legalMoves.any {
                                it.length >= 4 && it.substring(0, 2) == selectedSquare && it.substring(2, 4) == square
                            }
                            val baseColor = if ((rank + file) % 2 == 0) LightSquare else DarkSquare
                            val squareColor = when {
                                isSelected -> SelectedSquare
                                isLastMove -> blendColor(baseColor, SelectedSquare, 0.43f)
                                else -> baseColor
                            }

                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                                    .background(squareColor)
                                    .clickable(enabled = enabled) { onSquareTap(square) },
                                contentAlignment = Alignment.Center
                            ) {
                                if (file == 0) {
                                    Text(
                                        (rank + 1).toString(),
                                        color = if ((rank + file) % 2 == 0) DarkSquare else LightSquare,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.align(Alignment.TopStart).padding(3.dp)
                                    )
                                }
                                if (rank == 0) {
                                    Text(
                                        ('a'.code + file).toChar().toString(),
                                        color = if ((rank + file) % 2 == 0) DarkSquare else LightSquare,
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.align(Alignment.BottomEnd).padding(3.dp)
                                    )
                                }

                                if (hasPiece) {
                                    Text(
                                        pieceGlyph(pieceName),
                                        color = if (pieceName.startsWith("WHITE")) Color(0xFFFEFFF7) else Color(0xFF171C18),
                                        fontSize = cellFont,
                                        lineHeight = cellFont,
                                        fontWeight = FontWeight.Bold,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.shadow(if (pieceName.startsWith("WHITE")) 2.dp else 0.dp, CircleShape)
                                    )
                                }

                                if (isTarget) {
                                    if (hasPiece) {
                                        Canvas(Modifier.fillMaxSize().padding(4.dp)) {
                                            drawCircle(
                                                color = Color(0xAA1C241C),
                                                style = Stroke(width = 3.5.dp.toPx())
                                            )
                                        }
                                    } else {
                                        Canvas(Modifier.size(13.dp)) {
                                            drawCircle(Color(0x71303D31))
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ActionButton(
    icon: String,
    label: String,
    modifier: Modifier,
    enabled: Boolean,
    danger: Boolean = false,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (danger) Color(0xFF392321) else Panel)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text(icon, color = if (danger) Color(0xFFFF9388) else Accent, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, color = if (danger) Color(0xFFFFA29A) else WhiteText, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
    }
}

private fun formatTime(seconds: Int): String = "%02d:%02d".format(seconds / 60, seconds % 60)

private fun blendColor(start: Color, end: Color, fraction: Float): Color = Color(
    red = start.red + (end.red - start.red) * fraction,
    green = start.green + (end.green - start.green) * fraction,
    blue = start.blue + (end.blue - start.blue) * fraction,
    alpha = start.alpha + (end.alpha - start.alpha) * fraction
)

private fun pieceGlyph(pieceName: String): String = when (pieceName) {
    "WHITE_PAWN" -> "♙"
    "WHITE_KNIGHT" -> "♘"
    "WHITE_BISHOP" -> "♗"
    "WHITE_ROOK" -> "♖"
    "WHITE_QUEEN" -> "♕"
    "WHITE_KING" -> "♔"
    "BLACK_PAWN" -> "♟"
    "BLACK_KNIGHT" -> "♞"
    "BLACK_BISHOP" -> "♝"
    "BLACK_ROOK" -> "♜"
    "BLACK_QUEEN" -> "♛"
    "BLACK_KING" -> "♚"
    else -> ""
}

private object ChessAI {
    private const val MATE_SCORE = 100_000
    private const val INF = 1_000_000

    fun chooseMove(fen: String, difficulty: String): String? {
        val board = Board()
        board.loadFromFen(fen)
        val moves = orderedMoves(board)
        if (moves.isEmpty()) return null
        if (difficulty == "Easy") return moves.random().toString()

        val depth = if (difficulty == "Hard") 3 else 1
        var bestScore = INF
        val bestMoves = mutableListOf<String>()
        for (move in moves) {
            board.doMove(move)
            val score = search(board, depth - 1, -INF, INF)
            board.undoMove()
            when {
                score < bestScore -> {
                    bestScore = score
                    bestMoves.clear()
                    bestMoves.add(move.toString())
                }
                score == bestScore -> bestMoves.add(move.toString())
            }
        }
        return bestMoves.randomOrNull() ?: moves.first().toString()
    }

    private fun search(board: Board, depth: Int, alphaStart: Int, betaStart: Int): Int {
        if (board.isMated()) {
            return if (board.getSideToMove() == Side.WHITE) -MATE_SCORE - depth else MATE_SCORE + depth
        }
        if (board.isStaleMate() || board.isDraw()) return 0
        if (depth <= 0) return evaluate(board)

        val maximizing = board.getSideToMove() == Side.WHITE
        var alpha = alphaStart
        var beta = betaStart
        var best = if (maximizing) -INF else INF

        for (move in orderedMoves(board)) {
            board.doMove(move)
            val score = search(board, depth - 1, alpha, beta)
            board.undoMove()

            if (maximizing) {
                best = maxOf(best, score)
                alpha = maxOf(alpha, best)
            } else {
                best = minOf(best, score)
                beta = minOf(beta, best)
            }
            if (beta <= alpha) break
        }
        return best
    }

    private fun evaluate(board: Board): Int {
        var score = 0
        for (square in Square.values()) {
            if (square.name == "NONE") continue
            val pieceName = board.getPiece(square).name
            val value = when {
                pieceName.endsWith("PAWN") -> 100
                pieceName.endsWith("KNIGHT") -> 320
                pieceName.endsWith("BISHOP") -> 330
                pieceName.endsWith("ROOK") -> 500
                pieceName.endsWith("QUEEN") -> 900
                pieceName.endsWith("KING") -> 20_000
                else -> 0
            }
            score += when {
                pieceName.startsWith("WHITE_") -> value
                pieceName.startsWith("BLACK_") -> -value
                else -> 0
            }
        }
        return score
    }

    private fun orderedMoves(board: Board) = board.legalMoves().sortedByDescending { move ->
        val uci = move.toString()
        val destinationValue = if (uci.length >= 4) {
            val target = board.getPiece(Square.valueOf(uci.substring(2, 4).uppercase())).name
            when {
                target.endsWith("QUEEN") -> 900
                target.endsWith("ROOK") -> 500
                target.endsWith("BISHOP") -> 330
                target.endsWith("KNIGHT") -> 320
                target.endsWith("PAWN") -> 100
                else -> 0
            }
        } else 0
        destinationValue + if (uci.length > 4) 900 else 0
    }
}
